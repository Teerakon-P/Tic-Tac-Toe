<!DOCTYPE html>
<html>
    <head>
        <title>Tic Tac Toe</title>
    </head>
    <body>
        <center> 
            <div>
                <h1 style="color: black;">TIC-TAC-TOE</h1>
            </div> 
            <div>                      
                <button> X </button> 
                <button> O </button> 
                <br>
                <br>    
                <input type="button" value="RESET" onClick="reset()" /> 
            </div> 
        </center>
    </body>
</html><?php /**PATH C:\Users\POND\Desktop\TicTacToe\resources\views/layout/app.blade.php ENDPATH**/ ?>