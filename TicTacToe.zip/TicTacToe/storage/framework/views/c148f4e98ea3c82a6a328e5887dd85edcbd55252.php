       

<?php $__env->startSection('content'); ?> 

    <?php if($player == 'x'): ?>
        <h2>player 1 = X    player 2 = O</h2>
    <?php else: ?>
        <h2>player 1 = O    player 2 = X</h2>
    <?php endif; ?>

    <?php for($i = 0; $i < $value; $i++): ?>
        <?php for($j = 0; $j < $value; $j++): ?>
            <button> </button> 
        <?php endfor; ?>
        <br>
    <?php endfor; ?>

    <br>
    <form action="/1" method="get">
        <h2>Player ... Win</h2>     
        <button> New Game </button>
        </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\POND\Desktop\TicTacToe\resources\views/PlayGame.blade.php ENDPATH**/ ?>