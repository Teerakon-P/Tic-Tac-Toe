       

<?php $__env->startSection('content'); ?>
    
    <form action="/playGame" method="get">            
        <button> X </button> 
        <button> O </button>
    </form> 

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\POND\Desktop\TicTacToe\resources\views/choosePlayer.blade.php ENDPATH**/ ?>