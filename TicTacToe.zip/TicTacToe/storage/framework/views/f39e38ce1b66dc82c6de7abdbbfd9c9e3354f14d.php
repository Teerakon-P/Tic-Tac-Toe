       

<?php $__env->startSection('content'); ?>  
                   
    <form action="/1" method="get">
    <h2>Player ... Win</h2>     
    <button> New Game </button>
    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\POND\Desktop\TicTacToe\resources\views/endGame.blade.php ENDPATH**/ ?>