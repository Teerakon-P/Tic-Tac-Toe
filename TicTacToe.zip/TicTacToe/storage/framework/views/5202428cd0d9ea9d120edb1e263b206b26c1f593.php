<div>
    <h1 style="color: black;">TIC-TAC-TOE</h1>
</div> <?php /**PATH C:\Users\POND\Desktop\TicTacToe\resources\views/layout/head.blade.php ENDPATH**/ ?>