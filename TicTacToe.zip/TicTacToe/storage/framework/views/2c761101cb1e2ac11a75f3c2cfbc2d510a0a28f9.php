<?php 
if (isset($data['board'])) {
    $board = $data['board'];
    $winner = $data['winner'];
    $over = $data['over'];
}
?>
<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8" />
    <title>Tic Toe</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
</head>
<body>

<h4>TicToe Game</h4>

<?php if($winner): ?>
    <h3>Player <?php echo e($winner); ?> has won! <a href='<?php echo e(url("reset")); ?>'>Play Again?</a></h3><br>
<?php elseif($over): ?>
    Game Over! No body won! <a href='<?php echo e(url("reset")); ?>'>Play Again?</a></h3><br>
<?php endif; ?>

<br>
Player = X <br>
CPU = O

<table border="1" width="600px;" height="400px;">
<?php for($i=0; $i<3;$i++): ?>
    <tr>
    <?php for($n=0; $n<3;$n++): ?>
            <?php if(count($board) > 0 && $board[$i][$n] != ''): ?>
                <td><?php echo e($board[$i][$n]); ?></td>
            <?php else: ?>
                <?php  $num = "$i-$n"; ?>
               <td>
                <?php if(!$winner): ?>
                    <a href="<?php echo e(url('?select='.$num)); ?>">Select</a>
                <?php endif; ?>
                </td>
            <?php endif; ?>           
        <?php endfor; ?>
    </tr>
<?php endfor; ?>
</table>

</body>
</html><?php /**PATH C:\Users\POND\Desktop\TicTacToe\resources\views/index.blade.php ENDPATH**/ ?>