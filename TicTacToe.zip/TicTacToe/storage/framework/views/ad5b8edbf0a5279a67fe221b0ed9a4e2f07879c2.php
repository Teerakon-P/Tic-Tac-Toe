<?php 
if (isset($data['board'])) {
    $board = $data['board'];
    $winner = $data['winner'];
    $draw = $data['draw'];
}
?>

       

<?php $__env->startSection('content'); ?> 

    <?php if($player == 'X'): ?>
        <?php $player = 'O'; ?>
    <?php else: ?>
        <?php $player = 'X'; ?>
    <?php endif; ?>

    <?php if(!$winner): ?>
        <h4> Player : <?php echo e($player); ?>  </h4>
    <?php endif; ?>
        <br>
    <?php for($i = 0; $i < $value; $i++): ?>
        <?php for($j = 0; $j < $value; $j++): ?>
            <button type="button" class="btn btn-outline-dark">
                <?php if(count($board) > 0 && $board[$i][$j] != ''): ?>
                   <div class="xo"> <?php echo e($board[$i][$j]); ?> </div>
                <?php else: ?>
                    <?php  $num = "$i-$j"; ?>
                    <?php if(!$winner): ?>
                        <a href="<?php echo e(url('playGame?select='.$num.'&value='.$value.'&player='.$player)); ?>" class="text-decoration-none"> ? </a>
                    <?php endif; ?>
                <?php endif; ?>            
            </button>
        <?php endfor; ?>
        <br>
    <?php endfor; ?>
    <br>

    <form action="<?php echo e(url("reset")); ?>" method="get">
    <?php if($winner): ?>
        <h3> Player <?php echo e($winner); ?> Win ! </h3><br><button class="btn btn-light"> New Game </button><br>
    <?php elseif($draw): ?>
        <h3> Player Draw ! </h3><br><button class="btn btn-light"> New Game </button><br>
     <?php endif; ?>
    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\POND\Desktop\TicTacToe\resources\views/playGame.blade.php ENDPATH**/ ?>